<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <footer class="sobre-footer">
    <p>&copy; 2025 Crochet Penguin - Todos os direitos reservados.</p>
  </footer>
<footer class="site-footer">
        <div class="container">
            <div class="footer-columns">
                <div id="descubra" class="footer-column useful-links">
                    <h4>Descubra</h4>
                    <ul>
                        <li><a href="sobre.php">Sobre Nós</a></li>
                        <li><a href="atendimento.php">Atendimento</a></li>
                        <li><a href="contato.php">Entre em Contato</a></li>
                    </ul>
                </div>
                <div id="fale" class="footer-column contact-info">
                    <h4>Fale Conosco</h4>
                    <p>
                        <strong>Endereço:</strong> Beco do Café - Sonecalândia – PR<br>
                        <strong>Telefone:</strong> (11) 97724-4104<br>
                        <strong>Email:</strong> CrochetPenguim@gmail.com
                    </p>
                </div>
                <div id="horario" class="footer-column opening-hours">
                    <h4>Horário de Atendimento</h4>
                    <p>
                        <strong>Segunda a Sexta:</strong> 9h - 4h<br>
                        <strong>Sábado:</strong> 10h - 5h<br>
                        <strong>Domingo:</strong> 10h - 3h
                    </p>
                </div>
                </body>
                </html>