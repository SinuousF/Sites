-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 20/08/2025 às 16:54
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `penguin_crochet`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `Id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `usuário` varchar(50) DEFAULT NULL,
  `senha` varchar(20) DEFAULT NULL,
  `foto` varchar(20) DEFAULT NULL,
  `CEP` char(8) DEFAULT NULL,
  `Rua` varchar(40) DEFAULT NULL,
  `Bairro` varchar(50) DEFAULT NULL,
  `Numero` int(9) DEFAULT NULL,
  `UF` char(5) DEFAULT NULL,
  `Cidade` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `especificos`
--

CREATE TABLE `especificos` (
  `IdEspecificos` smallint(6) NOT NULL,
  `NomeEspecificos` varchar(50) NOT NULL,
  `IdTipo` smallint(6) DEFAULT NULL,
  `ImagemCapa` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `especificos`
--

INSERT INTO `especificos` (`IdEspecificos`, `NomeEspecificos`, `IdTipo`, `ImagemCapa`) VALUES
(1, 'Acessorios', 1, 'imagens/acesso.jpg'),
(2, 'Amigurumi', 2, 'imagens/amigu.jpg'),
(3, 'Las', 3, 'imagens/linhala.jpg'),
(4, 'Receitas', 4, 'imagens/receitas.jpg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `IdProduto` smallint(6) NOT NULL,
  `IdEspecificos` smallint(6) DEFAULT NULL,
  `IdTipo` smallint(6) DEFAULT NULL,
  `NomeProduto` varchar(100) NOT NULL,
  `PrecoProduto` decimal(10,2) DEFAULT NULL,
  `Quantidade` smallint(6) DEFAULT NULL,
  `Detalhes` text NOT NULL,
  `Cores` varchar(30) NOT NULL,
  `ImagemCapa` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`IdProduto`, `IdEspecificos`, `IdTipo`, `NomeProduto`, `PrecoProduto`, `Quantidade`, `Detalhes`, `Cores`, `ImagemCapa`) VALUES
(1, 3, 3, 'Lã Circulo Harmony - Lavanda 100g', 19.86, 100, 'Lã Acrílica de alta qualidade, com material resistente que impede desgasto futuro! Coloração de ótima qualidade.\r\n\r\nColeção Harmony, cor Lavanda.\r\n100 Gramas\r\n ', 'Lavanda', 'LAS/harmony/harmonylavanda.webp'),
(2, 3, 3, 'Lã Circulo Harmony - Branco 100g', 19.86, 95, 'Lã de alta performance, com resistência ao desgaste e cor firme por muito mais tempo.\r\n\r\nColeção Harmony, cor Branco.\r\n100 Gramas.', 'Branco', 'LAS/harmony/harmonybranco.webp'),
(3, 3, 3, 'Lã Circulo Baby pop - Frescor 100g', 19.86, 100, 'Lã leve, macia e com coloração refrescante para os dias especiais.\r\nColeção Babypop, cor Frescor.\r\n100 Gramas', 'Frescor', 'LAS\\babypop\\babypopfrescor.webp'),
(4, 3, 3, 'Lã Circulo Baby pop - Banho de Lua 100g', 29.86, 43, 'Lã acrílica super macia, perfeita para peças delicadas e aconchegantes.\r\nColeção Babypop, cor Banho de Lua.\r\n100 Gramas', 'Banho de lua', 'LAS\\babypop\\babypopbanhodelua.webp'),
(5, 3, 3, 'Lã Circulo Harmony - OFF-White 100g', 19.75, 110, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'OFF-White', 'LAS\\harmony\\harmonyoffwhite.webp'),
(6, 3, 3, 'Lã Circulo Harmony - Marfim 100g', 19.80, 90, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Marfim', 'LAS\\harmony\\harmonymarfim.webp'),
(7, 3, 3, 'Lã Circulo Harmony - Castanha 100g', 19.65, 100, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Castanha', 'LAS\\harmony\\harmonycastanha.webp'),
(8, 3, 3, 'Lã Circulo Harmony - Chocolate 100g', 19.90, 85, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Chocolate', 'LAS\\harmony\\harmonychocolate.webp'),
(9, 3, 3, 'Lã Circulo Harmony - Pimenta Síria 100g', 19.78, 95, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Pimenta Síria', 'LAS\\harmony\\harmonypimentasiria.webp'),
(10, 3, 3, 'Lã Circulo Harmony - Amêndoa 100g', 19.70, 100, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Amêndoa', 'LAS\\harmony\\harmonyamendoa.webp'),
(11, 3, 3, 'Lã Circulo Harmony - Begônia 100g', 19.85, 90, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Begônia', 'LAS\\harmony\\harmonybegonia.webp'),
(12, 3, 3, 'Lã Circulo Harmony - Rosa Algodão 100g', 19.65, 80, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Rosa Algodão', 'LAS\\harmony\\harmonyrosaalgodao.webp'),
(13, 3, 3, 'Lã Circulo Harmony - Tulipa 100g', 19.85, 105, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Tulipa', 'LAS\\harmony\\harmonytulipa.webp'),
(14, 3, 3, 'Lã Circulo Harmony - Barém 100g', 19.95, 78, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Barém', 'LAS\\harmony\\harmonybarem.webp'),
(15, 3, 3, 'Lã Circulo Harmony - Belvedere 100g', 29.54, 18, 'Maciez incomparável e coloração uniforme! Um fio que valoriza cada ponto do seu trabalho.\r\nColeção Harmony, cor Belvedere.\r\n100 Gramas', 'Barém', 'LAS\\harmony\\harmonybelvedere.webp'),
(16, 3, 3, 'Lã Circulo Boreal - Delicado 100g', 20.60, 110, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Delicado', 'LAS\\boreal\\borealdelicado.webp'),
(17, 3, 3, 'Lã Circulo Boreal - Floresta 100g', 20.70, 90, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Floresta', 'LAS\\boreal\\borealfloresta.webp'),
(18, 3, 3, 'Lã Circulo Boreal - Linum 100g', 20.55, 100, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Linum', 'LAS\\boreal\\boreallinum.webp'),
(19, 3, 3, 'Lã Circulo Boreal - Bonina 100g', 20.65, 85, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Bonina', 'LAS\\boreal\\borealbonina.webp'),
(20, 3, 3, 'Lã Circulo Boreal - Botão-de-Ouro 100g', 20.75, 95, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Botão-de-Ouro', 'LAS\\boreal\\borealbotaodeouro.webp'),
(21, 3, 3, 'Lã Circulo Boreal - Antúrio 100g', 20.68, 100, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Antúrio', 'LAS\\boreal\\borealanturio.webp'),
(22, 3, 3, 'Lã Circulo Boreal - Sonho 100g', 20.60, 110, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Sonho', 'LAS\\boreal\\borealsonho.webp'),
(23, 3, 3, 'Lã Circulo Boreal - Sereno 100g', 20.62, 95, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Sereno', 'LAS\\boreal\\borealsereno.webp'),
(24, 3, 3, 'Lã Circulo Boreal - Primorosa 100g', 20.70, 105, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Primorosa', 'LAS\\boreal\\borealprimorosa.webp'),
(25, 3, 3, 'Lã Circulo Majestoso - Prata Rosa 100g', 27.60, 110, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Prata Rosa', 'LAS\\majestoso\\majestosopratarosa.webp'),
(26, 3, 3, 'Lã Circulo Majestoso - Branco 100g', 27.55, 100, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Branco', 'LAS\\majestoso\\majestosobranco.webp'),
(27, 3, 3, 'Lã Circulo Majestoso - Creme de Manteiga 100g', 27.50, 95, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Creme de Manteiga', 'LAS\\majestoso\\majestosocremedemanteiga.webp'),
(28, 3, 3, 'Lã Circulo Majestoso - Andiroba 100g', 27.65, 90, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Andiroba', 'LAS\\majestoso\\majestosoandiroba.webp'),
(29, 3, 3, 'Lã Circulo Majestoso - Cobre 100g', 27.55, 85, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Cobre', 'LAS\\majestoso\\majestosocobre.webp'),
(30, 3, 3, 'Lã Circulo Majestoso - Marinho 100g', 27.60, 100, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Marinho', 'LAS\\majestoso\\majestosomarinho.webp'),
(31, 3, 3, 'Lã Circulo Majestoso - Chocolate 100g', 27.55, 105, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Chocolate', 'LAS\\majestoso\\majestosochocolate.webp'),
(32, 3, 3, 'Lã Circulo Majestoso - Picante 100g', 27.65, 95, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Picante', 'LAS\\majestoso\\majestosopicante.webp'),
(33, 3, 3, 'Lã Circulo Majestoso - Cinza Asfalto 100g', 27.50, 100, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Cinza Asfalto', 'LAS\\majestoso\\majestosocinzaasfalto.webp'),
(34, 3, 3, 'Lã Circulo Majestoso - Preto 100g', 27.55, 110, 'Lã acrílica de alta qualidade, ideal para peças confortáveis e resistentes.', 'Preto', 'LAS\\majestoso\\majestosopreto.webp'),
(35, 3, 3, 'Lã Circulo Baby pop - Arroz doce 100g', 19.90, 100, 'Lã acrílica super macia, perfeita para peças delicadas e aconchegantes.', 'Arroz doce', 'LAS\\babypop\\babypoparrozdoce.webp'),
(36, 3, 3, 'Lã Circulo Baby pop - Chá 100g', 19.85, 95, 'Lã acrílica super macia, perfeita para peças delicadas e aconchegantes.', 'Chá', 'LAS\\babypop\\babypopcha.webp'),
(37, 3, 3, 'Lã Circulo Baby pop - Jasmim 100g', 19.75, 90, 'Lã acrílica super macia, perfeita para peças delicadas e aconchegantes.', 'Jasmim', 'LAS\\babypop\\babypopjasmim.webp'),
(38, 3, 3, 'Lã Circulo Baby pop - Cegonha 100g', 19.80, 85, 'Lã acrílica super macia, perfeita para peças delicadas e aconchegantes.', 'Cegonha', 'LAS\\babypop\\babypopcegonha.webp'),
(39, 3, 3, 'Lã Circulo Baby pop - Fantasia 100g', 19.90, 100, 'Lã acrílica super macia, perfeita para peças delicadas e aconchegantes.', 'Fantasia', 'LAS\\babypop\\babypopfantasia.webp'),
(40, 3, 3, 'Lã Circulo Baby pop - Confete 100g', 19.85, 95, 'Lã acrílica super macia, perfeita para peças delicadas e aconchegantes.', 'Confete', 'LAS\\babypop\\babypopconfete.webp'),
(41, 3, 3, 'Lã Circulo Baby pop - Cafuné 100g', 19.75, 90, 'Lã acrílica super macia, perfeita para peças delicadas e aconchegantes.', 'Cafuné', 'LAS\\babypop\\babypopcafune.webp'),
(42, 3, 3, 'Lã Circulo Baby & Kids - Chiclete 100g', 22.90, 100, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Chiclete', 'LAS\\babykids\\babykidschiclete.webp'),
(43, 3, 3, 'Lã Circulo Baby & Kids - Branco 100g', 22.95, 95, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Branco', 'LAS\\babykids\\babykidsbranco.webp'),
(44, 3, 3, 'Lã Circulo Baby & Kids - Vitoriana 100g', 22.85, 90, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Vitoriana', 'LAS\\babykids\\babykidsvitoriana.webp'),
(45, 3, 3, 'Lã Circulo Baby & Kids - Blush 100g', 22.80, 85, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Blush', 'LAS\\babykids\\babykidsblush.webp'),
(46, 3, 3, 'Lã Circulo Baby & Kids - Clean 100g', 22.90, 100, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Clean', '\\LAS\\babykids\\babykidsclean.webp'),
(47, 3, 3, 'Lã Circulo Baby & Kids - Canário 100g', 22.95, 95, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Canário', 'LAS\\babykids\\babykidscanario.webp'),
(48, 3, 3, 'Lã Circulo Baby & Kids - Quartzo 100g', 22.85, 90, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Quartzo', 'LAS\\babykids\\babykidsquartzo.webp'),
(49, 3, 3, 'Lã Circulo Baby & Kids - Querubim 100g', 22.80, 85, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Querubim', 'LAS\\babykids\\babykidsquerubim.webp'),
(50, 3, 3, 'Lã Circulo Baby & Kids - Antonieta 100g', 22.90, 100, 'Lã acrílica macia e resistente, perfeita para peças infantis e confortáveis.', 'Antonieta', 'LAS\\babykids\\babykidsantonieta.webp'),
(51, 1, 1, 'Olhos para Amigurumi', 8.00, 250, 'Olhos plásticos de alta qualidade para seus amigurumis e artesanatos.', 'Preto', 'acessorios\\olhos.jpg'),
(52, 1, 1, 'Conjunto de Agulhas', 20.00, 200, 'Conjunto de agulhas, com diversas cores para não ficar na mesmice!', 'Metal', 'acessorios\\agulhaconjunto.png'),
(53, 1, 1, 'Agulha Circular', 15.00, 150, 'Agulha circular, dando mais facilidade para seus trabalhos\r\n\r\nPOSSUI CURVATURA.', 'Bambu', 'acessorios\\agulhacircularbambu.jpg'),
(55, 1, 1, 'Base para Crochê', 2.00, 200, 'Base prática para facilitar o manuseio e organização do crochê.', 'Branco', 'acessorios\\Base.webp'),
(56, 1, 1, 'Argola para chaveiro Corrente', 7.00, 240, 'Argola metálica para chaveiros com corrente, resistente e segura.', 'Metal', 'acessorios\\argola_alves.webp'),
(57, 1, 1, 'Agulha Soft Plus', 24.00, 300, 'Agulha resistente com cores diversas.\r\n\r\nCompre já a sua!!', 'Plástico', 'acessorios\\agulhasoftplus.png'),
(58, 1, 1, 'Kit iniciante Crochê sem Estojo', 75.00, 30, 'Kit completo para iniciantes em crochê\r\n\r\nEstojo não incluso.', 'Misto', 'acessorios\\kit_iniciante.webp'),
(59, 1, 1, 'Agulha Wing', 40.00, 40, 'Agulha personalizada e moderna, própria para trabalhos complexos.', 'Misto', 'acessorios\\agulhaswingminiaddi.jpg'),
(60, 2, 2, 'Kit Amigurumi bailarinas', 52.50, 10, 'Kit completo para criar amigurumis bailarinas detalhadas.', 'Misto', 'amigurumi\\kitbailarinas.jpg'),
(61, 2, 2, 'Kit Amigurumi Cão e Gato', 42.80, 10, 'Kit para criar amigurumis fofos de cão e gato.', 'Misto', 'amigurumi\\kitcaogato.webp'),
(62, 2, 2, 'Kit Amigurumi Natal', 43.90, 10, 'Kit temático para amigurumis natalinos e decorativos.', 'Misto', 'amigurumi\\kitnatal.jpeg'),
(63, 2, 2, 'Kit Amigurumi Chaveiro Hello Kitty', 60.00, 10, 'Kit para criar chaveiro amigurumi da Hello Kitty.', 'Misto', 'amigurumi\\kitchaveirohellokitty.png'),
(64, 2, 2, 'Kit Amigurumi Hello Kitty e Amigos', 49.89, 10, 'Kit para amigurumis da Hello Kitty e seus amigos.', 'Misto', 'amigurumi\\kithellokittyamigos.webp'),
(65, 1, 1, 'Argolas de Plástico', 24.49, 15, 'Agulha De Plástico, coloridas e uteis para todo tipo de trabalho.', 'Plastico', 'acessorios\\Argola_Plástico.jpg'),
(66, 1, 1, 'Alfinetão', 129.99, 10, 'Alfinetes grandes, para sua alegria e diversão!!', 'Plastico', 'acessorios\\Alfinetao.webp'),
(67, 1, 1, 'Alfinete', 19.95, 15, 'Conjunto de alfinetes, diversas cores.', 'Misto', 'acessorios\\Alfinete.webp'),
(68, 1, 1, 'Agulha Ponta Dupla', 18.00, 10, 'Precisa de mais pontas?? sem problemas!\r\n\r\nCompre já a Agulha com Pontas Duplas!!', 'Misto', 'acessorios\\agulhapontadupla.png'),
(70, 4, 4, 'Receita bruxinha Chloe', 0.00, NULL, 'Receita para criar a bruxinha Chloe em amigurumi.', 'N/A', 'receitas\\bruxinhachloereceita.jpg'),
(71, 4, 4, 'Receita Cachorrinho Bob', 0.00, NULL, 'Receita para criar o cachorrinho Bob em amigurumi.', 'N/A', 'receitas\\cachorrinhobobreceita.jpg'),
(72, 4, 4, 'Receita Coelho José', 0.00, NULL, 'Receita para criar o coelho José em amigurumi.', 'N/A', 'receitas\\coelhojosereceita.jpg'),
(73, 4, 4, 'Receita Milho Verde', 0.00, NULL, 'Receita para criar o milho verde em amigurumi.', 'N/A', 'receitas\\milhoverdereceita.png'),
(74, 4, 4, 'Receita raposinha Leonel', 0.00, NULL, 'Receita para criar a raposinha Leonel em amigurumi.', 'N/A', 'receitas\\raposinhaleonelreceita1.jpeg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tipo_produto`
--

CREATE TABLE `tipo_produto` (
  `IdTipo` smallint(6) NOT NULL,
  `TipoProduto` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tipo_produto`
--

INSERT INTO `tipo_produto` (`IdTipo`, `TipoProduto`) VALUES
(1, 'Acessorios'),
(2, 'Amigurumi'),
(3, 'Las'),
(4, 'Receitas');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`Id`);

--
-- Índices de tabela `especificos`
--
ALTER TABLE `especificos`
  ADD PRIMARY KEY (`IdEspecificos`),
  ADD KEY `fk_id_Tipo` (`IdTipo`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`IdProduto`),
  ADD KEY `fk_id_Tipos` (`IdTipo`),
  ADD KEY `fk_id_Penguins` (`IdEspecificos`);

--
-- Índices de tabela `tipo_produto`
--
ALTER TABLE `tipo_produto`
  ADD PRIMARY KEY (`IdTipo`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cadastro`
--
ALTER TABLE `cadastro`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `especificos`
--
ALTER TABLE `especificos`
  MODIFY `IdEspecificos` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `IdProduto` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT de tabela `tipo_produto`
--
ALTER TABLE `tipo_produto`
  MODIFY `IdTipo` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `especificos`
--
ALTER TABLE `especificos`
  ADD CONSTRAINT `fk_id_Tipo` FOREIGN KEY (`IdTipo`) REFERENCES `tipo_produto` (`IdTipo`);

--
-- Restrições para tabelas `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `fk_id_Penguins` FOREIGN KEY (`IdEspecificos`) REFERENCES `especificos` (`IdEspecificos`),
  ADD CONSTRAINT `fk_id_Tipos` FOREIGN KEY (`IdTipo`) REFERENCES `tipo_produto` (`IdTipo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
