// Inicialização dos Tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
})


//Modal
  const form = document.getElementById("formLogin");

  form.addEventListener("submit", function (e) {
    e.preventDefault(); // Impede envio padrão

    // Campos
    const nomeInput = document.getElementById("nomeLogin");
    const emailInput = document.getElementById("emailLogin");
    const telefoneInput = document.getElementById("telefoneLogin");
    const enderecoInput = document.getElementById("enderecoLogin");
    const senhaInput = document.getElementById("senhaLogin");

    // Valores
    const nome = nomeInput.value.trim();
    const email = emailInput.value.trim();
    const telefone = telefoneInput.value.trim();
    const endereco = enderecoInput.value.trim();
    const senha = senhaInput.value;

    // Expressões regulares
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const senhaRegex = /^(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    const telefoneRegex = /^\(?\d{2}\)?[\s-]?\d{4,5}-?\d{4}$/;

    const telInput = document.getElementById("telefoneLogin");
    telInput.addEventListener("input", function () {
      let valor = telInput.value.replace(/\D/g, "");

      if (valor.length > 11) valor = valor.slice(0, 11);

      if (valor.length > 10) {
        valor = valor.replace(/^(\d{2})(\d{5})(\d{4}).*/, "($1) $2-$3");
      } else if (valor.length > 6) {
        valor = valor.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, "($1) $2-$3");
      } else if (valor.length > 2) {
        valor = valor.replace(/^(\d{2})(\d{0,5})/, "($1) $2");
      } else {
        valor = valor.replace(/^(\d*)/, "($1");
      }

      telInput.value = valor;
    });

    // Resetar classes
    const inputs = [nomeInput, emailInput, telefoneInput, enderecoInput, senhaInput];
    inputs.forEach(input => input.classList.remove("is-valid", "is-invalid"));

    let valid = true;

    if (nome === "") {
      nomeInput.classList.add("is-invalid");
      valid = false;
    } else {
      nomeInput.classList.add("is-valid");
    }

    if (!emailRegex.test(email)) {
      emailInput.classList.add("is-invalid");
      valid = false;
    } else {
      emailInput.classList.add("is-valid");
    }

    if (!telefoneRegex.test(telefone)) {
      telefoneInput.classList.add("is-invalid");
      valid = false;
    } else {
      telefoneInput.classList.add("is-valid");
    }

    if (endereco === "") {
      enderecoInput.classList.add("is-invalid");
      valid = false;
    } else {
      enderecoInput.classList.add("is-valid");
    }

    if (!senhaRegex.test(senha)) {
      senhaInput.classList.add("is-invalid");
      valid = false;
    } else {
      senhaInput.classList.add("is-valid");
    }

    if (valid) {
      // ✅ Tudo certo: fechar o modal
      const modalEl = document.getElementById("modalLogin");
      const modalInstance = bootstrap.Modal.getInstance(modalEl);
      modalInstance.hide();

      // Exemplo de ação após validação
      alert("✅ Formulário validado com sucesso!");
    }
  });