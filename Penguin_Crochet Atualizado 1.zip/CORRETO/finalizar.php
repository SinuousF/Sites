<?php
session_start();
include("conexao.php");

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// Busca os dados do usuário logado
$sql = "SELECT * FROM cadastro WHERE Id = ?";
$stmt = mysqli_prepare($strcon, $sql);
mysqli_stmt_bind_param($stmt, "i", $usuario_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$usuario = mysqli_fetch_assoc($result);

// Preenche os dados com o que vier do banco
$nome     = $usuario['nome']     ?? '';
$cep      = $usuario['CEP']      ?? '';
$endereco = $usuario['Rua']      ?? '';
$numero   = $usuario['Numero']   ?? '';
$bairro   = $usuario['Bairro']   ?? '';
$cidade   = $usuario['Cidade']   ?? '';
$uf       = $usuario['UF']       ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome     = $_POST['nome']     ?? '';
    $cep      = $_POST['cep']      ?? '';
    $endereco = $_POST['endereco'] ?? '';
    $numero   = $_POST['numero']   ?? '';
    $bairro   = $_POST['bairro']   ?? '';
    $cidade   = $_POST['cidade']   ?? '';
    $uf       = $_POST['uf']       ?? '';
    $pagamento = $_POST['pagamento'] ?? '';

    echo "<script>alert('Pedido finalizado com sucesso!');</script>";
    unset($_SESSION['carrinho']);
    echo "<script>window.location.href = 'index.php';</script>";
    exit;
}
?>

<?php require_once("cabeca2.php"); ?>
<!DOCTYPE html>
<html lang="PT-BR">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atendimento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
<body id="finalizar-body">

<div id="finalizar-container">
    <div class="form-section">
        <h2>Informações de Entrega</h2>
        <form method="post">
            <label for="nome"><b>Nome Completo</b></label>
            <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($nome) ?>">

            <label for="cep"><b>CEP</b></label>
            <input type="text" id="cep" name="cep" value="<?= htmlspecialchars($cep) ?>">

            <label for="endereco"><b>Endereço</b></label>
            <input type="text" id="endereco" name="endereco" value="<?= htmlspecialchars($endereco) ?>">

            <label for="numero"><b>Número</b></label>
            <input type="text" id="numero" name="numero" value="<?= htmlspecialchars($numero) ?>">

            <label for="bairro"><b>Bairro</b></label>
            <input type="text" id="bairro" name="bairro" value="<?= htmlspecialchars($bairro) ?>">

            <label for="cidade"><b>Cidade</b></label>
            <input type="text" id="cidade" name="cidade" value="<?= htmlspecialchars($cidade) ?>">

            <label for="uf"><b>UF</b></label>
            <input type="text" id="uf" name="uf" value="<?= htmlspecialchars($uf) ?>">

            <h2>Pagamento</h2>
            <div class="radio-group">
                <input type="radio" id="credito" name="pagamento" value="Credito" checked>
                <label for="credito">Cartão de Crédito</label><br>
                <input type="radio" id="debito" name="pagamento" value="Debito">
                <label for="debito">Cartão de Débito</label><br>
                <input type="radio" id="pix" name="pagamento" value="PIX">
                <label for="pix">PIX</label>
            </div>

            <button type="submit" class="btn-finalizar">Finalizar Pedido</button>
        </form>
    </div>

    <div class="resumo-section">
        <h2>Resumo do Pedido</h2>
        <?php
        if (!empty($_SESSION['carrinho'])) {
            $total = 0;
            foreach ($_SESSION['carrinho'] as $item) {
                $nomeItem = $item['nome'] ?? 'Produto';
                $preco = $item['preco'] ?? 0;
                $qtd = $item['quantidade'] ?? 1;

                echo "<p>$nomeItem - R$ " . number_format($preco, 2, ',', '.') . " (x$qtd)</p>";
                $total += $preco * $qtd;
            }
            echo "<hr><b>Total: R$ " . number_format($total, 2, ',', '.') . "</b>";
        } else {
            echo "<p>Seu carrinho está vazio.</p>";
        }
        ?>
    </div>
</div>
<?php include("footer.php"); ?>
</body>
</html>
