<?php
session_start();
include_once('conexao.php');

// Inicializa o carrinho
if (!isset($_SESSION['carrinho'])) $_SESSION['carrinho'] = [];

// Remover item
if (isset($_GET['remover'])) {
    $idRemover = $_GET['remover'];
    unset($_SESSION['carrinho'][$idRemover]);
    header('Location: carrinho.php');
    exit;
}

// Adicionar ou atualizar item via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['idproduto'])) {
    $id = $_POST['idproduto'];
    $nome = $_POST['nome'];
    $preco = floatval($_POST['preco']);
    $imagem = $_POST['imagem'];
    $qtdDesejada = intval($_POST['quantidade']);

    // Consulta estoque real
    $res = mysqli_query($strcon, "SELECT Quantidade FROM Produtos WHERE IdProduto = $id");
    $row = mysqli_fetch_assoc($res);
    $estoqueReal = intval($row['Quantidade']);

    if (isset($_SESSION['carrinho'][$id])) {
        $novaQtd = $_SESSION['carrinho'][$id]['quantidade'] + $qtdDesejada;
        $_SESSION['carrinho'][$id]['quantidade'] = min($novaQtd, $estoqueReal);
    } else {
        $_SESSION['carrinho'][$id] = [
            'nome' => $nome,
            'preco' => $preco,
            'imagem' => $imagem,
            'quantidade' => min($qtdDesejada, $estoqueReal)
        ];
    }

    header('Location: carrinho.php');
    exit;
}

// Atualizar quantidade diretamente no carrinho (+ / -)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar'])) {
    foreach ($_POST['quantidade'] as $id => $qtd) {
        $qtd = intval($qtd);
        $res = mysqli_query($strcon, "SELECT Quantidade FROM Produtos WHERE IdProduto = $id");
        $row = mysqli_fetch_assoc($res);
        $estoqueReal = intval($row['Quantidade']);
        $_SESSION['carrinho'][$id]['quantidade'] = max(1, min($qtd, $estoqueReal));
    }
    header('Location: carrinho.php');
    exit;
}

require_once('cabeca2.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
<body>
    
</body>
</html>
<main class="container mt-5">
    <?php if (!empty($_SESSION['carrinho'])): ?>
        <div class="row">
            <!-- Seção dos produtos -->
            <div class="col-lg-8">
                <h3 class="mb-4">Carrinho de Compras</h3>
                <form method="POST" action="carrinho.php">
                    <?php
                    $totalGeral = 0;
                    foreach ($_SESSION['carrinho'] as $id => $item):
                        $total = $item['preco'] * $item['quantidade'];
                        $totalGeral += $total;
                    ?>
                    <div class="card mb-3 p-3 shadow-sm">
                        <div class="row g-3 align-items-center">
                            <div class="col-md-2">
                                <img src="<?php echo htmlspecialchars($item['imagem']); ?>" alt="Imagem do produto" class="img-fluid rounded">
                            </div>
                            <div class="col-md-4">
                                <h5 class="mb-1"><?php echo htmlspecialchars($item['nome']); ?></h5>
                                <p class="text-muted mb-0">Preço: R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></p>
                            </div>
                            <div class="col-md-3 d-flex align-items-center">
                                <button type="button" class="btn btn-outline-secondary btn-sm me-2" onclick="alterarQtd(<?php echo $id; ?>, -1)">-</button>
                                <input type="number" name="quantidade[<?php echo $id; ?>]" value="<?php echo $item['quantidade']; ?>" min="1" class="form-control text-center" style="width:60px;">
                                <button type="button" class="btn btn-outline-secondary btn-sm ms-2" onclick="alterarQtd(<?php echo $id; ?>, 1)">+</button>
                            </div>
                            <div class="col-md-2">
                                <p class="mb-0">Total: <strong>R$ <?php echo number_format($total, 2, ',', '.'); ?></strong></p>
                            </div>
                            <div class="col-md-1 text-end">
                                <a href="carrinho.php?remover=<?php echo $id; ?>" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>

                    <button type="submit" name="atualizar" class="btn btn-primary">Atualizar Quantidades</button>
                </form>
            </div>

            <!-- Seção de resumo -->
            <div class="col-lg-4">
                <div class="card shadow-sm p-4">
                    <h4 class="mb-3">Resumo da Compra</h4>
                    <p>Total dos Produtos:</p>
                    <h5 class="text-primary">R$ <?php echo number_format($totalGeral, 2, ',', '.'); ?></h5>
                    <div class="mt-4 d-grid gap-2">
                        <a href="index.php" class="btn btn-outline-dark">Continuar Comprando</a>

                        <a href="finalizar.php" class="btn nome">Finalizar Compra</a>

                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <p class="text-center vazio">Seu carrinho está vazio</p>
        <div class="text-center mt-3">
            <a href="index.php" class="btn btn-outline-primary">Voltar à loja</a>
        </div>
    <?php endif; ?>
</main>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<script>
function alterarQtd(id, delta) {
    const input = document.querySelector(`input[name="quantidade[${id}]"]`);
    let val = parseInt(input.value);
    val += delta;
    if(val < 1) val = 1;
    input.value = val;
}
</script>

<?php require_once('footer.php'); ?>
