<?php require_once("cabeca2.php"); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sobre Nós - Crochet Penguin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
<body class="sobre-body">

  <header class="sobre-banner">
    <h1>Crochet Penguin</h1>
    <p>Entre pontos e fios, contamos histórias de aconchego.</p>
  </header>

  <main class="container my-5 sobre-main">
    <section class="sobre-intro">
      <h2>Sobre Nós</h2>
      <p>Conheça mais sobre a essência da <b>Crochet Penguin</b>. Cada peça é feita com carinho e dedicação, refletindo nossa paixão pelo crochê e o cuidado com cada detalhe.</p>
    </section>

    <section class="row g-4 justify-content-center sobre-cards">

      <!-- Card 1 -->
      <div class="col-12 col-md-6 col-lg-4 col-xl-3">
        <div class="sobre-card">
          <div class="sobre-card-wrapper">
            <img src="imagens/NaraHeart.jpg" class="sobre-main-img" alt="Início">
            <img src="imagens/alves.jpg" class="sobre-hover-img sobre-hidden" alt="Início Hover">
          </div>
          <div class="sobre-text sobre-main-text">Fiz o preparo e cuidado do CSS, além de apoio em outras áreas, como a página inicial desse site.</div>
          <div class="sobre-text sobre-hover-text sobre-hidden">Unindo estética e lógica em cada projeto.</div>
        </div>
      </div>

      <!-- Card 2 -->
      <div class="col-12 col-md-6 col-lg-4 col-xl-3">
        <div class="sobre-card">
          <div class="sobre-card-wrapper">
            <img src="imagens/samimi.jpg" class="sobre-main-img" alt="Equipe">
            <img src="imagens/samira.jpg" class="sobre-hover-img sobre-hidden" alt="Equipe Hover">
          </div>
          <div class="sobre-text sobre-main-text">Fiz o banco de dados e a criação da página de produtos, minhas opiniões com o CSS foram muito significativas.</div>
          <div class="sobre-text sobre-hover-text sobre-hidden">Bordando entre fios e códigos.</div>
        </div>
      </div>

      <!-- Card 3 -->
      <div class="col-12 col-md-6 col-lg-4 col-xl-3">
        <div class="sobre-card">
          <div class="sobre-card-wrapper">
            <img src="imagens/tutuba4.png" class="sobre-main-img" alt="Qualidade">
            <img src="imagens/nathalia.jpg" class="sobre-hover-img sobre-hidden" alt="Qualidade Hover">
          </div>
          <div class="sobre-text sobre-main-text">Selecionei os melhores produtos e materiais de altíssima qualidade. E os adicionei no banco de dados! </div>
          <div class="sobre-text sobre-hover-text sobre-hidden">Tecelando entre linhas de raciocíonio e lógica.</div>
        </div>
      </div>

      <!-- Card 4 -->
      <div class="col-12 col-md-6 col-lg-4 col-xl-3">
        <div class="sobre-card">
          <div class="sobre-card-wrapper">
            <img src="imagens/florintino.png" class="sobre-main-img" alt="Inspiração">
            <img src="imagens/florentino.jpg" class="sobre-hover-img sobre-hidden" alt="Inspiração Hover">
          </div>
          <div class="sobre-text sobre-main-text">Auxiliei na criação das páginas, e fui responsável pela criação do cadastro e login de usuarios.</div>
          <div class="sobre-text sobre-hover-text sobre-hidden">Jogando entre a criação e a unificação.</div>
        </div>
      </div>

      <!-- Card 5 -->
      <div class="col-12 col-md-6 col-lg-4 col-xl-3">
        <div class="sobre-card">
          <div class="sobre-card-wrapper">
            <img src="imagens/Biel_1.png" class="sobre-main-img" alt="Comunidade">
            <img src="imagens/biel.jpg" class="sobre-hover-img sobre-hidden" alt="Comunidade Hover">
          </div>
          <div class="sobre-text sobre-main-text">Realizei o tratamento de imagens, além de apoio em outras áreas, como essa página atual.</div>
          <div class="sobre-text sobre-hover-text sobre-hidden">Lavo o rosto nas águas sagradas da pia.</div>
        </div>
      </div>

    </section>
  </main>



  <script>
    document.querySelectorAll('.sobre-card').forEach(card => {
      const mainImg = card.querySelector('.sobre-main-img');
      const hoverImg = card.querySelector('.sobre-hover-img');
      const mainText = card.querySelector('.sobre-main-text');
      const hoverText = card.querySelector('.sobre-hover-text');

      card.addEventListener('mouseenter', () => {
        mainImg.classList.add('sobre-hidden');
        hoverImg.classList.remove('sobre-hidden');
        mainText.classList.add('sobre-hidden');
        hoverText.classList.remove('sobre-hidden');
      });

      card.addEventListener('mouseleave', () => {
        mainImg.classList.remove('sobre-hidden');
        hoverImg.classList.add('sobre-hidden');
        mainText.classList.remove('sobre-hidden');
        hoverText.classList.add('sobre-hidden');
      });
    });
  </script>
<?php include("footer.php"); ?>
</body>
</html>
