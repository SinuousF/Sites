<?php session_start();

if(!isset($_SESSION['valid'])) {
    header('Location: login.php');
}

include("conexao.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $user = $_POST['usuario'];
    $pass = $_POST['senha'];
    $cep = $_POST['CEP'];
    $rua = $_POST['Rua'];
    $bairro = $_POST['Bairro'];
    $numero = $_POST['Numero'];
    $uf = $_POST['UF'];
    $cidade = $_POST['Cidade'];


if (empty($nome) || empty($email) || empty($cep) || empty($rua) || empty($bairro) || empty($numero) || empty($uf) || empty($cidade)) {
    if (empty($nome)) {
        echo "Campo Nome está vazio.<br>";
    }
    if (empty($email)) {
        echo "Campo E-mail está vazio.<br><br>";
        echo"<a href='editarCadastro.php'>Voltar</a>";
    }
    if (empty($cep)) {
        echo "Campo CEP está vazio.<br>";
    }
    if (empty($rua)) {
        echo "Campo Rua está vazio.<br>";
    }
    if (empty($bairro)) {
        echo "Campo Bairro está vazio.<br>";
    }
    if (empty($numero)) {
        echo "Campo Número está vazio.<br>";
    }
    if (empty($uf)) {
        echo "Campo UF está vazio.<br>";
    }
    if (empty($cidade)) {
        echo "Campo Cidade está vazio.<br>";
    }

    exit;
}

if (empty($pass)) {
    $sql = "UPDATE cadastro
            SET nome = '$nome', email = '$email', CEP = '$cep', Rua = '$rua', Bairro = '$bairro', Numero = '$numero', UF = '$uf', Cidade = '$cidade'
            WHERE id = $id";
    $resultado = mysqli_query($strcon, $sql);
    header("Location: index.php");
    exit;

}
 else {
    $hashsenha = password_hash($pass, PASSWORD_DEFAULT);
    $sql = "UPDATE cadastro
            SET nome = '$nome', email = '$email', senha = '$hashsenha', CEP = '$cep', Rua = '$rua', Bairro = '$bairro', Numero = '$numero', UF = '$uf', Cidade = '$cidade'
            WHERE id = $id";
    $resultado = mysqli_query($strcon, $sql);

    session_destroy();
    header("Location: index.php");
    exit;

}
}

$id = $_SESSION ['id'];

$sql = "SELECT * FROM cadastro WHERE id = $id";
$consulta = mysqli_query($strcon, $sql);

while($res = mysqli_fetch_array($consulta)) {
    $nome = $res['nome'];
    $email = $res['email'];
    $user = $res['usuario'];
    $pass = $res['senha'];
    $cep = $res['CEP'];
    $rua = $res['Rua'];
    $numero = $res['Numero'];
    $bairro = $res['Bairro'];
    $uf = $res['UF'];
    $cidade = $res['Cidade'];

}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="estilo.css">
    <title>Editar Usuários</title>
</head>

<body>
    <div class="container mt-4">

    <a href="index.php">Início</a>
    <br><br>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-10 col-md-6 col-lg-4">
                <form id="formCadastro"atualizaCadastro" method="POST" action="editarCadastro.php">
                    <div class="mb-3">
                        <label for="usuario" class="form-label"><strong>Usuário</strong></label>
                        <input type="text" class="form-control" id="usuario" name="usuario" value="<?php echo htmlspecialchars($user);?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="nome" class="form-label"><strong>Nome</strong></label>
                        <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($nome);?>">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label"><strong>E-mail</strong></label>
                        <input type="text" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email);?>">
                    </div>
                   
                    <div class="mb-3">
                        <label for="CEP" class="form-label"><strong>CEP</strong></label>
                        <input type="text" class="form-control" id="CEP" name="CEP" value="<?php echo htmlspecialchars($cep);?>">
                    </div>

                    <div class="mb-3">
                        <label for="Rua" class="form-label"><strong>Rua</strong></label>
                        <input type="text" class="form-control" id="Rua" name="Rua" value="<?php echo htmlspecialchars($rua);?>">
                    </div>


                    <div class="mb-3">
                        <label for="Bairro" class="form-label"><strong>Bairro</strong></label>
                        <input type="text" class="form-control" id="Bairro" name="Bairro" value="<?php echo htmlspecialchars($bairro);?>">
                    </div>

                    <div class="mb-3">
                        <label for="Numero" class="form-label"><strong>Número</strong></label>
                        <input type="text" class="form-control" id="Numero" name="Numero" value="<?php echo htmlspecialchars($numero);?>">
                    </div>

                    <div class="mb-3">
                        <label for="UF" class="form-label"><strong>UF</strong></label>
                        <input type="text" class="form-control" id="UF" name="UF" value="<?php echo htmlspecialchars($uf)?>">
                    </div>

                    <div class="mb-3">
                        <label for="Cidade" class="form-label"><strong>Cidade</strong></label>
                        <input type="text" class="form-control" id="Cidade" name="Cidade" value="<?php echo htmlspecialchars($cidade);?>">
                    </div>

                    <div class="mb-3">
                        <label for="senha" class="form-label"><strong>Senha.</strong><br> obs: Deixar esse campo em branco não altera a senha cadastrada. </label>
                        <input type="password" class="form-control" id="senha" name="senha">
                    </div>

           
                    <div class="mb-3">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($_SESSION['id']);?>">
                        <input type="submit" class="btn btn-primary" name="update" value="Atualizar">
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<script>

document.getElementById("formCadastro").addEventListener("submit", function(e) {
    let cep = document.getElementById("CEP").value.replace(/\D/g, '');

    // Se CEP estiver vazio ou inválido, bloqueia o submit
    if (cep.length !== 8) {
        e.preventDefault(); // 🔴 impede o envio
        alert("Por favor, insira um CEP válido.");
        return;
    }
});
// Script para preencher automaticamente os campos ao digitar o CEP
let ultimoCep = '';

document.getElementById('CEP').addEventListener('blur', function () {
    let cep = this.value.replace(/\D/g, '');    

    // Evita repetir alerta se já for o mesmo CEP
    if (cep === ultimoCep) return;
    ultimoCep = cep;

    if (cep.length === 8) {
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(response => response.json())
            .then(data => {
                if (!data.erro) {
                    document.getElementById('Rua').value = data.logradouro;
                    document.getElementById('Bairro').value = data.bairro;
                    document.getElementById('Cidade').value = data.localidade;
                    document.getElementById('UF').value = data.uf;
                } else {
                    alert("CEP não encontrado.");
                }
            })
            .catch(() => alert("Erro ao buscar CEP."));
    } else if (cep.length > 0) {
        alert("CEP inválido.");
    }
});

</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>