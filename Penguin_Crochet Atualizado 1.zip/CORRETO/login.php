<?php
session_start();
include("conexao.php");

if(isset($_POST['submit'])) {
    $user = mysqli_real_escape_string($strcon, $_POST['username']);
    $pass = mysqli_real_escape_string($strcon, $_POST['password']);

    if($user == "" || $pass == "") {
        echo "Nome de usuário ou senha vazios.<br>";
        echo "<a href='index.php'>Voltar</a>";
        exit;
    } else {
        $sql = "SELECT * FROM cadastro WHERE usuario = '$user'";
        $res = mysqli_query($strcon, $sql) or die ("Erro ao efetuar login");

        $linha = mysqli_fetch_assoc($res);

        if($linha && password_verify($pass, $linha['senha'])) {
            $_SESSION['valid'] = $linha['usuario'];
            $_SESSION['name'] = $linha['nome'];
            $_SESSION['id'] = $linha['Id'];
            $_SESSION['usuario_id'] = $linha['Id']; 
            $_SESSION['email'] = $linha['email'];
            $_SESSION['cep'] = $linha['CEP'];
            $_SESSION['rua'] = $linha['Rua'];
            $_SESSION['bairro'] = $linha['Bairro'];
            $_SESSION['numero'] = $linha['Numero'];
            $_SESSION['uf'] = $linha['UF'];
            $_SESSION['cidade'] = $linha['Cidade'];

            header("Location: index.php");
            exit;
        } else {
            echo "Nome de usuário ou senha incorretos<br>";
            echo "<a href='index.php'>Voltar</a>";
            exit;
        }
    }
}
?>