<?php
include_once("conexao.php"); 

// Pega o tipo vindo pela URL (ex: produtos.php?tipo=2)
if (isset($_GET['tipo'])) {
    $idTipo = (int)$_GET['tipo'];
} else {
    $idTipo = 0;
}

// Se não tiver tipo válido, manda de volta pra index
if ($idTipo <= 0) {
    header("Location: index.php"); 
    exit(); 
}

// ------------------------------------------------- Consultar Produtos -----------------------------------------------------------------------------------------------------
$pesquisa = isset($_GET['q']) ? trim($_GET['q']) : "";

$sqlProdutos = "
    SELECT p.IdProduto, p.NomeProduto, p.PrecoProduto, p.Quantidade, 
           p.ImagemCapa, tp.TipoProduto
    FROM Produtos p
    JOIN Tipo_Produto tp ON p.IdTipo = tp.IdTipo
    WHERE p.IdTipo = ?
";

if (!empty($pesquisa)) {
    $sqlProdutos .= " AND p.NomeProduto LIKE ?";
}

$stmtProdutos = mysqli_prepare($strcon, $sqlProdutos);

$produtosEncontrados = false;
$resultProdutos = null;

if ($stmtProdutos) {
    if (!empty($pesquisa)) {
        $pesquisaLike = "%" . $pesquisa . "%";
        mysqli_stmt_bind_param($stmtProdutos, "is", $idTipo, $pesquisaLike);
    } else {
        mysqli_stmt_bind_param($stmtProdutos, "i", $idTipo);
    }

    mysqli_stmt_execute($stmtProdutos);
    $resultProdutos = mysqli_stmt_get_result($stmtProdutos);

    if (mysqli_num_rows($resultProdutos) > 0) {
        $produtosEncontrados = true;
    }
}
?>

<?php require_once("cabeca.php"); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crochet Penguin - Produtos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
<body>

<main class="col-md-12 ">
    <div class="container" id="produtos">
        <h3 id="maismais"><b>Produtos</b></h3>
        <div class="row">
            <?php
            if ($produtosEncontrados) {
                while ($produto = mysqli_fetch_assoc($resultProdutos)) {
                    $tipoPasta = htmlspecialchars($produto['TipoProduto']);
                    $nomeArquivo = !empty($produto['ImagemCapa']) 
                                   ? htmlspecialchars($produto['ImagemCapa']) 
                                   : "placeholder.webp";

                    $caminhoCompleto = "Imagens/PRODUTOSPENGUIN/" . $produto['ImagemCapa'];
                    ?>
                    <div class="col-12 col-sm-6 col-md-3 d-flex justify-content-center p-2">
                        <div class="produto-card card" style="width: 18rem;">
                            <img src="<?php echo $caminhoCompleto; ?>" class="card-img-top" alt="Produto">
                            <div class="card-body">
                                <h5 class="card-title textinho"><?php echo htmlspecialchars($produto['NomeProduto']); ?></h5>
                                <p class="card-text textinho">
                                    <strong id="preco_produto">Preço:</strong><span id="preco_produto_detalhe"> R$ <?php echo number_format($produto['PrecoProduto'], 2, ',', '.'); ?> </span><br>
                                    <strong id="quantidade_produto">Quantidade:</strong><span id="preco_produto_detalhe"> <?php echo htmlspecialchars($produto['Quantidade']); ?></span><br>
                                </p>
                                <button class="btn detalhe" onclick="window.location.href='detalhes_produto.php?id=<?php echo htmlspecialchars($produto['IdProduto']); ?>'">Detalhes</button>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<div class="col-12 text-center"><p>Nenhum produto encontrado.</p></div>';
            }
            ?>
        </div>
    </div>
</main>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php include("footer.php") ?>

</body>
</html>

<?php
if (isset($stmtProdutos)) {
    mysqli_stmt_close($stmtProdutos);
}
mysqli_close($strcon);
?>
