<?php session_start(); ?>
<?php require_once("cabeca2.php"); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penguin Crochet</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
<body>

<div id="bannerCarousel" class="carousel slide" data-bs-ride="carousel">
  <!-- indicadores -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="0" class="active" aria-current="true"></button>
    <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="2"></button>
  </div>

  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="ratio ratio-21x9 bg-dark">
        <img src="Imagens/PRODUTOSPENGUIN/bannercrochet.jpg" class="banner-img" alt="Banner 1">
      </div>
    </div>
    <div class="carousel-item">
      <div class="ratio ratio-21x9 bg-dark">
        <img src="Imagens/PRODUTOSPENGUIN/Banner_2.webp" class="banner-img" alt="Banner 2">
      </div>
    </div>
    <div class="carousel-item">
      <div class="ratio ratio-21x9 bg-dark">
        <img src="Imagens/PRODUTOSPENGUIN/Banner_3.jpg" class="banner-img" alt="Banner 3">
      </div>
    </div>
  </div>

  <button class="carousel-control-prev" type="button" data-bs-target="#bannerCarousel" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
    <span class="visually-hidden">Anterior</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#bannerCarousel" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
    <span class="visually-hidden">Próximo</span>
  </button>
</div>


<main class="col-md-12">

  <!-- 1. Categorias em destaque -->
  <section class="container my-5">
    <h3 class="mb-4"><b>Categorias em Destaque</b></h3>
    <div class="row g-4">
      <div class="col-md-3">
        <div id="redondo" class="card categoria-card">
          <img src="Imagens\pinguimla.webp" class="card-img-top" alt="Lãs">
          <div class="card-body text-center">
            <h5>Lãs</h5>
            <a href="produtos.php?tipo=3" class="btn btn-primary">Ver Produtos</a>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div id="redondo" class="card categoria-card">
          <img src="Imagens\herbertamigurumi.png" class="card-img-top" alt="Amigurumi">
          <div class="card-body text-center">
            <h5>Amigurumi</h5>
            <a href="produtos.php?tipo=2" class="btn btn-primary">Ver Produtos</a>
          </div>
        </div>
      </div>
      <div id="redondo" class="col-md-3">
        <div class="card categoria-card">
          <img src="Imagens\pinguimreceita.webp" class="card-img-top" alt="Receitas">
          <div class="card-body text-center">
            <h5>Receitas</h5>
            <a href="produtos.php?tipo=4" class="btn btn-primary">Ver Produtos</a>
          </div>
        </div>
      </div>
      <div id="redondo" class="col-md-3">
        <div class="card categoria-card">
          <img src="Imagens\pinguimacessorio.webp" class="card-img-top" alt="Acessórios">
          <div class="card-body text-center">
            <h5>Acessórios</h5>
            <a href="produtos.php?tipo=1" class="btn btn-primary">Ver Produtos</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 2. Novidades -->
  <section class="container my-5">
    <h3 class="mb-4"><b>Novidades</b></h3>
    <div class="row g-4">
      <div class="col-6 col-md-3">
        <div class="card produto-novo">
          <img src="Imagens/PRODUTOSPENGUIN/LAS/harmony/harmonyrosaalgodao.webp" class="card-img-top" alt="Produto Novo 1">
          <div class="card-body text-center">
            <p class="mb-0">Lã Harmony</p>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="card produto-novo">
          <img src="Imagens/PRODUTOSPENGUIN/amigurumi/kithellokittyamigos.webp" class="card-img-top" alt="Produto Novo 2">
          <div class="card-body text-center">
            <p class="mb-0">Hello Kitty Amigurumi</p>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="card produto-novo">
          <img src="Imagens/PRODUTOSPENGUIN/receitas/bruxinhachloereceita.jpg" class="card-img-top" alt="Produto Novo 3">
          <div class="card-body text-center">
            <p class="mb-0">Receita Crochê</p>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="card produto-novo">
          <img src="Imagens/PRODUTOSPENGUIN/acessorios/agulhasoftplus.png" class="card-img-top" alt="Produto Novo 4">
          <div class="card-body text-center">
            <p class="mb-0">Acessório Premium</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 4. Depoimentos -->
  <section class="container my-5">
    <h3 class="mb-4"><b>O que nossos clientes dizem</b></h3>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="depoimento">"Os amigurumis são bem resistentes a água, eu amei!!!"<br><b>- Nami</b></div>
      </div>
      <div class="col-md-4">
        <div class="depoimento">"Comprei meu kit de agulhas e são extremamente úteis!"<br><b>- Gwen</b></div>
      </div>
      <div class="col-md-4">
        <div class="depoimento">"Produtos fofos com entrega na velocidade da LUZ"<br><b>- Lux</b></div>
      </div>
    </div>
  </section>


  <!-- 6. Banner Promocional -->
  <section class="container my-5">
    <div class="banner-promo">
      <h4><b>🎁 Embalamos para presente!</b></h4>
      <p>Aproveite já e entregue algo especial!!</p>
    </div>
  </section>

</main>

<?php include("footer.php"); ?>


</body>
</html>
