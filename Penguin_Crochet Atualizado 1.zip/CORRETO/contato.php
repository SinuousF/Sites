<?php require_once("cabeca2.php"); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entre em Contato - Crochet Penguin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
<body>

<div id="contato-container" class="container my-5">

    <h2 id="contato-titulo" class="text-center mb-4">Entre em Contato</h2>
    <p id="contato-subtitulo" class="text-center mb-5">
        Quer conversar sobre crochê, pinguins ou dar feedback sobre o site? Preencha o formulário abaixo!
    </p>

    <div class="row justify-content-center">

        <!-- Formulário -->
        <div class="col-md-6">
            <form id="contato-form" class="p-4 rounded shadow-sm">
                
                <div class="mb-3">
                    <label for="contato-nome" class="form-label">Nome</label>
                    <input type="text" class="form-control" id="contato-nome" placeholder="Seu nome">
                </div>

                <div class="mb-3">
                    <label for="contato-email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="contato-email" placeholder="seu@email.com">
                </div>

                <div class="mb-3">
                    <label for="contato-mensagem" class="form-label">Mensagem</label>
                    <textarea class="form-control" id="contato-mensagem" rows="5" placeholder="Escreva sua mensagem..."></textarea>
                </div>

                <button type="submit" class="btn btn-primary w-100">Enviar</button>
            </form>
        </div>

        <!-- Imagem decorativa -->
        <div class="col-md-4 d-none d-md-flex justify-content-center align-items-center">
            <img id="contato-imagem" src="Imagens/decora.jpg" alt="Pinguim Crochet" class="img-fluid">
        </div>
    </div>
</div>
<?php include("footer.php"); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
