
<!DOCTYPE html>
<html lang="PT-BR">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atendimento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
<header>
<div class="col-md-12 container-fluid p-0">
  <nav class="navbar barrinha">
    <div class="container-fluid">
      <a class="navbar-brand p-0 m-0" href="index.php"><img src="Logo.png" width="90" height="90" alt=""></a>

      <div id="menuSite" class="d-flex align-items-center gap-3">
        <a href="#" class="btn btn-outline-light d-md-none">
          <i button type="button" class="bi bi-search" data-bs-toggle="modal" data-bs-target="#modalPesquisa"></i>
          </a>

        <a href="carrinho.php" class="btn btn-outline-light">
          <i class="bi bi-cart"></i> </a>
        
<?php
if(isset($_SESSION['valid'])) {
?>
  <div class="dropdown">
    <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
      Olá, <?php echo isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name']) : 'Usuário'; ?>
    </button>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="logout.php">Sair</a></li>
    </ul>
  </div>
<?php
} else {
?>
  <a href="#" class="btn btn-outline-light" onclick="toggleSidebar()" data-bs-toggle="modal" data-bs-target="#modalLogin">
    <i class="bi bi-person"></i> </a>
<?php
}
?>

        <a href="sobre.php" class="btn btn-outline-light">Sobre</a>
      </div>
    </div>
  </nav>

  <div class="modal fade" id="modalLogin" tabindex="-1" aria-labelledby="modalLoginLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalLoginLabel">Login</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <form id="formLogin" method="POST" action="login.php">
            <div class="mb-3">
                <label for="username" class="form-label">User:</label>
                <input type="text" class="form-control" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Senha:</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                <button type="submit" class="btn btn-primary" name="submit">Login</button>
                <a href="cadastro.php" type="button" class="btn btn-primary">Cadastre-se</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<nav class="container-fluid barra">
  <div class="row">
    <a id="botao_fora_la" href="produtos.php?tipo=1" class="botao">Acessórios</a>
    <a id="botao_fora" href="produtos.php?tipo=2" class="botao">Amigurumi</a>
    <a id="botao_fora" href="produtos.php?tipo=3" class="botao">Lãs</a>
    <a id="botao_fora_acss" href="produtos.php?tipo=4" class="botao">Receitas</a>
  </div>
</nav>
</header>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>