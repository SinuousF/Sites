<?php require_once("cabeca2.php"); ?>
<!DOCTYPE html>
<html lang="PT-BR">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atendimento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
 
<body>

 
    <!-- Conteúdo Principal -->
    <div class="container my-5">
        <div class="row g-4">
            <!-- Formulário de Contato -->
            <div class="col-lg-7">
                <div class="contact-form imenso">
                    <h3 class="mb-4">Envie uma mensagem</h3>
                    <form>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="nome" class="form-label">Nome</label>
                                <input type="text" class="form-control" id="nome" required>
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">E-mail</label>
                                <input type="email" class="form-control" id="email" required>
                            </div>
                            <div class="col-12">
                                <label for="assunto" class="form-label">Assunto</label>
                                <select class="form-select" id="assunto" required>
                                    <option value="" selected disabled>Selecione...</option>
                                    <option value="duvida">Dúvida sobre produtos</option>
                                    <option value="pedido">Status de pedido</option>
                                    <option value="sugestao">Sugestão</option>
                                    <option value="reclamacao">Reclamação</option>
                                    <option value="outro">Outro</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label for="mensagem" class="form-label">Mensagem</label>
                                <textarea class="form-control" id="mensagem" rows="5"
                                    required></textarea>
                            </div>
                            <div class="col-12">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="newsletter">
                                    <label class="form-check-label" for="newsletter">
                                        Desejo receber novidades e promoções por e-mail
                                    </label>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-contact">Enviar Mensagem</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
 
            <!-- Informações de Contato -->
            <div class="col-lg-5">
                <div class="contact-info contatos">
                    <h3 class="mb-4">Nossos Canais</h3>
                    <div class="mb-4">
                        <h5><i class="bi bi-geo-alt-fill contact-icon"></i> Endereço</h5>
                        <p>Beco do Café - Sonecalândia – PR<br>Cidade Segura - SP<br>CEP: 12345-678</p>
                    </div>
                    <div class="mb-4">
                        <h5><i class="bi bi-telephone-fill contact-icon"></i> Telefones</h5>
                        <p>(11) 98289-8806 (WhatsApp)<br>(11) 97724-4104 (Comercial)</p>
                    </div>
                    <div class="mb-4">
                        <h5><i class="bi bi-envelope-fill contact-icon"></i> E-mail</h5>
                        <p>CrochetPenguim@gmail.com<br>SuporteCrochetPenguim@gmail.com</p>
                    </div>
                    <div class="mb-4">
                        <h5><i class="bi bi-clock-fill contact-icon"></i> Horário de Atendimento</h5>
                        <p>Segunda a Sexta: 9h - 4h<br>Sábado: 10h - 5h<br>Domingo: 10h - 3h</p>
                    </div>
                    <div class="social-links">
                        <h5><i class="bi bi-people-fill contact-icon"></i> Redes Sociais</h5>
                        <a href="#" class="btn btn-outline-dark me-2"><i class="bi bi-facebook"></i></a>
                        <a href="https://www.instagram.com/cpenguinbrasil/" class="btn btn-outline-dark me-2"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="btn btn-outline-dark me-2"><i class="bi bi-whatsapp"></i></a>
                        <a href="https://youtu.be/V7iQ88W7QWQ" class="btn btn-outline-dark"><i class="bi bi-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
 
        <!-- Mapa -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="map-container">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d646.4140540945974!2d-46.582584195123445!3d-23.58028951096066!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce5c11b493da03%3A0x5eff5e0d20f89f6c!2sSenac%20Vila%20Prudente!5e0!3m2!1spt-BR!2sbr!4v1752497229160!5m2!1spt-BR!2sbr"
                            width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>
 
    <?php require_once("footer.php"); ?>
 
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
 
</html>
 