<?php
session_start();
include_once("conexao.php");

// Pega o ID do produto da URL
$idProduto = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($idProduto <= 0) {
    header("Location: produtos.php");
    exit();
}

// Consulta produto
$sqlProduto = "
    SELECT p.IdProduto, p.NomeProduto, p.PrecoProduto, p.Quantidade, p.Detalhes,
           p.ImagemCapa, tp.TipoProduto
    FROM Produtos p
    JOIN Tipo_Produto tp ON p.IdTipo = tp.IdTipo
    WHERE p.IdProduto = ?
";
$stmtProduto = mysqli_prepare($strcon, $sqlProduto);
$produtoEncontrado = false;
$produto = null;

if ($stmtProduto) {
    mysqli_stmt_bind_param($stmtProduto, "i", $idProduto);
    mysqli_stmt_execute($stmtProduto);
    $resultProduto = mysqli_stmt_get_result($stmtProduto);

    if (mysqli_num_rows($resultProduto) > 0) {
        $produto = mysqli_fetch_assoc($resultProduto);
        $produtoEncontrado = true;
    }
    mysqli_stmt_close($stmtProduto);
} else {
    error_log("Erro na consulta de produto: " . mysqli_error($strcon));
}

require_once("cabeca2.php");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Produto</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="CSS/casa.css">
</head>
<body>
<div class="container my-5">
    <?php if ($produtoEncontrado): ?>
        <?php
            $nomeArquivo = !empty($produto['ImagemCapa']) ? htmlspecialchars($produto['ImagemCapa']) : "placeholder.webp";
            $caminhoCompleto = "Imagens/PRODUTOSPENGUIN/" . $nomeArquivo;
        ?>
        <div class="row">
            <!-- Imagem do Produto -->
            <div id="produto_fotao" class="col-md-6 d-flex justify-content-center align-items-center produtao">
                <img src="<?php echo $caminhoCompleto; ?>" class="img-fluid rounded shadow" alt="Produto">
            </div>

            <!-- Informações do Produto -->
            <div id="produto_detalhado" class="col-md-6 produtao">
                <h2 id="titulo_produto"><?php echo htmlspecialchars($produto['NomeProduto']); ?></h2>
                <p id="descricao_produto" class="lead"><?php echo nl2br(htmlspecialchars($produto['Detalhes'] ?? "Descrição não disponível.")); ?></p>
                <p>
                    <strong id="detalhes_preco">Preço:</strong> <span id="detalhes_preco_detalhe" class="text-success fs-4">R$ <?php echo number_format($produto['PrecoProduto'], 2, ',', '.'); ?></span><br>
                    <strong id="detalhes_estoque">Estoque:</strong> <span id="detalhes_estoque_detalhe" class="fs-4"><?php echo htmlspecialchars($produto['Quantidade']); ?>
                </p>

                <!-- Formulário de Adição ao Carrinho -->
                <form id="form_produto" method="POST" action="carrinho.php" class="d-flex align-items-center gap-2">
                    <input type="hidden" name="idproduto" value="<?php echo $produto['IdProduto']; ?>">
                    <input type="hidden" name="nome" value="<?php echo htmlspecialchars($produto['NomeProduto']); ?>">
                    <input type="hidden" name="preco" value="<?php echo $produto['PrecoProduto']; ?>">
                    <input type="hidden" name="imagem" value="<?php echo $caminhoCompleto; ?>">

                    <button type="button" class="btn btn-outline-secondary" onclick="decrement()">-</button>
                    <input type="number" name="quantidade" id="quantidade" value="1" min="1" max="<?php echo $produto['Quantidade']; ?>" class="form-control text-center" style="width: 70px;">
                    <button type="button" class="btn btn-outline-secondary" onclick="increment()">+</button>

                    <button type="submit" class="btn btn-primary">Adicionar ao Carrinho</button>
                </form>

                <script>
                    const quantidadeInput = document.getElementById('quantidade');
                    const estoque = <?php echo $produto['Quantidade']; ?>;

                    function increment() {
                        let val = parseInt(quantidadeInput.value);
                        if(val < estoque) quantidadeInput.value = val + 1;
                    }
                    function decrement() {
                        let val = parseInt(quantidadeInput.value);
                        if(val > 1) quantidadeInput.value = val - 1;
                    }
                </script>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger text-center">
            Produto não encontrado.
        </div>
    <?php endif; ?>
</div>

<?php include("footer.php"); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php mysqli_close($strcon); ?>
