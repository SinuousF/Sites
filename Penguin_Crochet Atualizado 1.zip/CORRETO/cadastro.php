<?php
session_start();
include("conexao.php");

// Processa o cadastro antes de qualquer HTML
if(isset($_POST['submit'])) {

    // Sanitizar dados
    $nome   = mysqli_real_escape_string($strcon, $_POST['name']);
    $email  = mysqli_real_escape_string($strcon, $_POST['email']);
    $user   = mysqli_real_escape_string($strcon, $_POST['username']);
    $pass   = mysqli_real_escape_string($strcon, $_POST['password']);
    $cep    = mysqli_real_escape_string($strcon, $_POST['CEP']);
    $rua    = mysqli_real_escape_string($strcon, $_POST['Rua']);
    $bairro = mysqli_real_escape_string($strcon, $_POST['Bairro']);
    $numero = mysqli_real_escape_string($strcon, $_POST['Numero']);
    $uf     = mysqli_real_escape_string($strcon, $_POST['UF']);
    $cidade = mysqli_real_escape_string($strcon, $_POST['Cidade']);

    // Verifica campos vazios
    if($user=="" || $pass=="" || $nome=="" || $email=="" || $cep=="" || $rua=="" || $bairro=="" || $numero== "" || $uf=="" || $cidade== "") {
        $erro = "Todos os campos devem ser preenchidos.";
    } else {
        // Verifica se usuário ou email já existe
        $checkUser = mysqli_query($strcon, "SELECT * FROM cadastro WHERE usuario='$user' OR email='$email'");
        if(mysqli_num_rows($checkUser) > 0) {
            $erro = "Usuário ou email já cadastrados!";
        } else {
            // Cria hash da senha
            $hashsenha = password_hash($pass, PASSWORD_DEFAULT);

            // Insere no banco
            $sql = "INSERT INTO cadastro(nome, email, usuario, senha, CEP, Rua, Bairro, Numero, UF, Cidade)
                    VALUES ('$nome','$email','$user','$hashsenha','$cep','$rua','$bairro','$numero','$uf','$cidade')";
            if(mysqli_query($strcon, $sql)) {
                // Cadastro OK, redireciona direto para index.php
                header("Location: index.php");
                exit;
            } else {
                $erro = "Erro no cadastro: " . mysqli_error($strcon);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Penguin Crochet - Registrar</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="CSS/casa.css">
</head>
<body>
<div class="container mt-5">
<h2>Registrar</h2>
<?php
        if(isset($erro)) {
            echo "<div class='alert alert-danger'>$erro</div>";
        }
    ?>
<div class="container bg-light p-4 rounded shadow">
<h4 class="mb-4">Cadastro</h4>
<form name="registro" method="POST" action="">
<div class="row g-3">
<div class="col-md-6">
<label class="form-label">Nome</label>
<input type="text" class="form-control" name="name" required><br>
</div>
<div class="col-md-6">
<label class="form-label">E-mail</label>
<input type="email" class="form-control" name="email" required><br>
</div>
<div class="col-md-6">
<label class="form-label">Usuário</label>
<input type="text" class="form-control" name="username" required autocomplete="off"><br>
</div>
<div class="col-md-6">
<label class="form-label">Senha</label>
<input type="password" class="form-control" name="password" required autocomplete="new-password"><br>
</div>
<div class="col-md-4">
<label class="form-label">CEP</label>
<input type="text" class="form-control" id="CEP" name="CEP" placeholder="00000-000" required>
</div>
<div class="col-md-4">
<label class="form-label">Rua</label>
<input type="text" class="form-control" id="Rua" name="Rua" required>
</div>
<div class="col-md-4">
<label class="form-label">Bairro</label>
<input type="text" class="form-control" id="Bairro" name="Bairro" required>
</div>
<div class="col-md-2">
<label class="form-label">Número</label>
<input type="text" class="form-control" name="Numero" required>
</div>
<div class="col-md-1">
<label class="form-label">UF</label>
<input type="text" class="form-control" id="UF" name="UF" maxlength="2" required>
</div>
<div class="col-md-6">
<label class="form-label">Cidade</label>
<input type="text" class="form-control" id="Cidade" name="Cidade" required>
</div>
</div>
<br>
<input type="submit" class="btn btn-primary" name="submit" value="Registrar">
</form>
</div>
</div>

<script>
// Preenche automaticamente os campos ao digitar o CEP
document.getElementById('CEP').addEventListener('blur', function () {
    let cep = this.value.replace(/\D/g, '');
    if (cep.length === 8) {
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
        .then(response => response.json())
        .then(data => {
            if (!data.erro) {
                document.getElementById('Rua').value = data.logradouro;
                document.getElementById('Bairro').value = data.bairro;
                document.getElementById('Cidade').value = data.localidade;
                document.getElementById('UF').value = data.uf;
            } else {
                alert("CEP não encontrado.");
            }
        })
        .catch(() => alert("Erro ao buscar CEP."));
    } else {
        alert("CEP inválido.");
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>