<?php
$servidor = "localhost";
$usuario = "Penguim";
$senha = "123";
$banco = "penguin_crochet";
$strcon = mysqli_connect($servidor, $usuario, $senha, $banco);
if (!$strcon) {
    die("Banco de dados inacessivel");
}
?>